Place Java plugins (.jar) and Rust plugins (directories containing manifest.json
and .wasm) in this folder.

Java plugins: the launcher reads plugin.yml, validates metadata, api-version and
the Java class-file version, and reports dependency order. Plugin code is NOT
executed yet (no Bukkit API implementation); see docs/JAVA-PLUGIN-COMPATIBILITY.md.

Rust/WASM plugins: the engine validates manifest.json, the API version and the
\0asm header. No WASM runtime is linked in this build, so nothing is executed;
see docs/RUST-PLUGIN-DEVELOPMENT.md.
